# 载入包
library(uba)                  #获取uba中的F指标
library(e1071)                # 用于支持向量回归建模
library(pls)                  # 用于偏最小二乘回归建模
library(stats)               # 用于线性回归建模
library(rpart)                # 用于决策树建模
library(earth)                #多元自适应回归样条
library(caret)
library(dplyr)
library(DMwR)                 #获取目标变量列(resp函数)
library(IRon)                 #获取相关函数并计算评价指标SERA
library(WeightSVM)            # 用于加权支持向量回归建模

#清除环境变量
rm(list=ls())

#设置路径
setwd("E:/Desktop/SVMIR/R/Finalcode/0523local-modelWSVR")
source("metric.R")
source("TargetRelvance.R")

# 设置路径，准备数据集
setwd("E:/Desktop/SVMIR/R/47data")
dataset <- read.csv("house16H.csv")

# 定义回归问题
form <- as.formula("y ~ .")

# 获取目标变量列
y <- DMwR::resp(form, dataset)

####使用IRon包获取目标变量的相关性值####
IRonph <- IRon::phi.control(y)
IRony.phi <- IRon::phi(y,IRonph)

###指标F中损失函数的计算###
lossF.args <- uba::loss.control(y)

# 相关性阈值设定
tE <- 0.8

#普通值和稀有值划分
rare.cases <- which(IRony.phi > tE)
rare <- dataset[rare.cases,]
common <- dataset[-rare.cases,]

#不平衡率
IR <- round(nrow(common)/ nrow(rare), 2)
print(IR)

###SVR加权的权重函数
wf0.5 <- TargetRelevance(y, alpha = 0.5)
rels0.5 <- as.data.frame(wf0.5$eval(y))

wf1 <- TargetRelevance(y, alpha = 1)
rels1 <- as.data.frame(wf1$eval(y))

wf1.5 <- TargetRelevance(y, alpha = 1.5)
rels1.5 <- as.data.frame(wf1.5$eval(y))

###定义算法名称和函数####
methods <- list(
  "PLS" = function(train, test) {
    trainControl <- trainControl(method = "boot", number = 10)
    model <- caret::train(y ~ ., data = train, method = "pls", trControl = trainControl)
    predict(model, test[,-ncol(test)])
  },
  
  "Linear Regression" = function(train, test) {
    model <- stats::lm(y ~ ., data = train)
    predict(model, test[,-ncol(test)])
  },
  
  "Decision Tree" = function(train, test) {
    model <- rpart::rpart(y ~ ., data = train)
    predict(model, test[,-ncol(test)])
  }, 
  
  "Multivariate Adaptive Regression Splines" = function(train, test) {
    model <- earth::earth(y ~ ., data = train)
    predict(model, test[,-ncol(test)])
  },
  
  "Support Vector Regression" = function(train, test) {
    model <- e1071::svm(y ~ ., data = train)
    predict(model, test[,-ncol(test)])
  },
  
  "Weighted SVRwrs" = function(train, test) {
    wrs <- c(rep(0.2, length(train1)), rep(0.8, length(train2)))
    model <- WeightSVM::wsvm(y ~ ., data = train, weight = wrs)
    predict(model, test[,-ncol(test)])
  },
  
  "Weighted SVRwIRon" = function(train, test) {
    IRony.phi <- as.data.frame(IRony.phi)
    wIRon <- IRony.phi[row.names(train),]
    # 根据wuba将样本拆分成权重为0和非0的两个子集
    zeros <- wIRon == 0
    non_zeros <- wIRon != 0
    
    # 从训练数据中删除需要删除的样本和权重为0的值
    train <- train[non_zeros, ]
    wIRon <- wIRon[non_zeros]
    
    # 运行更新后的数据生成模型
    model <- WeightSVM::wsvm(y ~ ., data = train, weight = wIRon)
    predict(model, test[,-ncol(test)])
  },
  
  "Weighted SVRwf0.5" = function(train, test) {
    model <- WeightSVM::wsvm(y ~ ., data = train, weight = rels0.5[row.names(train),])
    predict(model, test[,-ncol(test)])
  },
  
  "Weighted SVRwf1" = function(train, test) {
    model <- WeightSVM::wsvm(y ~ ., data = train, weight = rels1[row.names(train),])
    predict(model, test[,-ncol(test)])
  },
  
  "Weighted SVRwf1.5" = function(train, test) {
    model <- WeightSVM::wsvm(y ~ ., data = train, weight = rels1.5[row.names(train),])
    predict(model, test[,-ncol(test)])
  }
)

####存储所有模型/指标组合的列名####
models <- c("PLS", "LM", "DT", "MARS", "SVR", "WSVRrs", "WSVRIRon", "WSVR0.5", "WSVR1", "WSVR1.5")
metrics <- c("RMSE", "MAE", "RMSEr", "MAEr", "SERA", "ubaF1", "ubaprec", "ubarec")

#####定义结果矩阵#####
col_names <- c()
for (n in 1:length(models)) {
  for (m in 1:length(metrics)) {
    col_names <- c(col_names, paste(models[n], metrics[m], sep = "."))
  }
}
col_names <- c(col_names, "Iteration")
results <- data.frame(matrix(NA, nrow = 50, ncol = length(models) * length(metrics) + 1))
colnames(results) <- col_names

# 进行50次试验
for (i in 1:50) {
  # 划分训练集和测试集
  set.seed(i)
  train1<-sample(nrow(common), 0.7*nrow(common), replace = FALSE)
  train2<-sample(nrow(rare), 0.7*nrow(rare), replace = FALSE)
  train<-rbind(common[train1,], rare[train2,])
  test <-rbind(common[-train1,], rare[-train2,])
  
  # 对每个算法进行训练和预测
  row <- c()
  for (j in 1:length(models)) {
    method <- methods[[j]]
    predicted <- method(train, test)
    row <- c(row, rmse(actual = test$y, predicted = predicted), 
             mae(actual = test$y, predicted = predicted), 
             rmser(actual = test$y, predicted = predicted, phiactual = IRon::phi(test$y, IRonph), tE = tE), 
             maer(actual = test$y, predicted = predicted, phiactual = IRon::phi(test$y, IRonph), tE = tE),
             sera(test$y, predicted, IRon::phi(test$y, IRonph)),
             eval.stats(actual = test$y, predicted = predicted, tE = tE, method = IRonph$method, npts = IRonph$npts, 
                        control.pts = IRonph$control.pts, ymin = lossF.args$ymin, ymax = lossF.args$ymax, 
                        tloss = lossF.args$tloss, epsilon = lossF.args$epsilon)
    )
  }
  row <- c(row, i)
  results[i, ] <- row
}

##### 计算均值和标准差 ####
means <- apply(results[,1:ncol(results)-1], 2, mean)
sds <- apply(results[,1:ncol(results)-1], 2, sd)

##### 合并均值和标准差为一个数据框 #####
summary <- data.frame(Means = round(means, 3), SDs = round(sds, 3))

#####汇总最终结果####
finresult <- split(summary[, 1:2], gsub(".*\\.", "", rownames(summary)))
print(finresult)

#设置结果路径
setwd("E:/Desktop/SVMIR/R/Finalcode/0523local-modelWSVR/0523result")

# 添加均值和标准差的文本字符串
for (key in names(finresult)) {
  mean_sd <- mapply(function(x, y) {
    paste0(x, " (", y, ")")}, 
    finresult[[key]]$Means, finresult[[key]]$SDs)
  finresult[[key]] <- mean_sd
}

# 将所有指标的结果拼接在一起
result_string <- paste(unlist(finresult), collapse = ", ")
# 将结果保存为CSV文件
writeLines(result_string, "house16H-tablecopy.csv")

#### 将结果保存到CSV文件中 ####
write.csv(results, file = "house16H-results.csv", row.names = FALSE)

##### 将数据框保存为 CSV 文件 ####
write.csv(summary, file = "house16H-summary.csv")