library(KernSmooth)
TargetRelevance <- function(y, alpha) {
  
  alpha <- alpha
 
  silverman_bandwidth <- 1.06 * sd(y) * length(y) ^ (-1.0 / 5.0)
  
  best_bandwidth <- silverman_bandwidth
  
  kernel <- bkde(y, bandwidth = best_bandwidth)
  
  y_dens <- kernel$y
  y_dens <- scales::rescale(y_dens)#将数据重新缩放到指定的范围（默认是0到1）
  
  eps <- 1e-6
  w2 <- pmax(1 - alpha * y_dens, eps)#pmax函数用于比较两个向量的对应元素，返回一个新的向量，其中第i个元素等于第一个向量的第i个元素和第二个向量的第i个元素的最大值。避免w2中出现0或负数。
  mean_w2 <- mean(w2)
  relevances <- w2 / mean_w2
  
  get_density <- function(y) {
    stats::approx(kernel$x, kernel$y, xout = y)$y
  }
  
  eval_single <- function(y) {
    dens <- get_density(y)
    pmax(1 - alpha * dens, eps) / mean_w2
  }
  
  eval <- function(y) {
    ys <- as.vector(y)
    rels <- sapply(ys, eval_single)
  }
  
  list( eval = eval, kernel = kernel, y_min = min(y), y_max = max(y), x = kernel$x ) }