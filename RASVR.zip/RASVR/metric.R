#定义评价指标函数
rmse <- function(actual, predicted) {
  sqrt(mean((predicted - actual)^2))
}

mae <- function(actual, predicted) {
  mean(abs(predicted - actual))
}

maer <- function(actual, predicted, phiactual, tE) {
  tb <- data.frame(predicted - actual, phiactual)
  colnames(tb) <- c("pe", "phi")
  maer <- mean(abs(tb[tb$phi>tE,]$pe))
  return(maer)
}

rmser <- function(actual, predicted, phiactual, tE){
  tbl <- data.frame(predicted - actual, phiactual)
  colnames(tbl) <- c("pt", "phi")
  rmser<- sqrt(mean((tbl[tbl$phi>tE,]$pt)^2))
  return (rmser)
}  

eval.stats <- function(actual, predicted, stats, tE, method, npts, control.pts, 
                       ymin, ymax, tloss, epsilon) {
  ph <- list()
  ph$method <- method
  ph$npts <- npts
  ph$control.pts <- control.pts
  lossF.args <- list()
  lossF.args$ymin <- ymin
  lossF.args$ymax <- ymax
  lossF.args$tloss <- tloss
  lossF.args$epsilon <- epsilon
  
  ubaprec <- uba::util(predicted, actual, ph, lossF.args, util.control(umetric="P", event.thr=tE))
  ubarec <- uba::util(predicted, actual, ph, lossF.args, util.control(umetric="R", event.thr=tE))
  ubaF1 <- uba::util(predicted, actual, ph, lossF.args, util.control(umetric="Fm", beta=1, event.thr=tE))
  
  return(list(ubaF1=ubaF1, ubaprec=ubaprec, ubarec=ubarec))
}
